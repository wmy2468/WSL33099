/***********************************

> 應用名稱：pixiv 去广告
> 軟件版本：7.14.9
> 下載地址：https://apps.apple.com/us/app/id337248563
> 腳本作者：Cuttlefish
> 微信賬號：墨魚手記
> 解鎖說明：解鎖高級會員權限
> 更新時間：2022-05-19
> 通知頻道：https://t.me/ddgksf2021
> 問題反饋：https://t.me/ddgksf2013_bot
> 特別說明：⛔⛔⛔
            本腳本僅供學習交流使用，禁止轉載售賣
            ⛔⛔⛔

[rewrite_local]

# ～ Pixiv去除广告（2022-05-19）@ddgksf2013
^https?:\/\/oauth\.secure\.pixiv\.net\/(auth\/token) url script-response-body https://github.com/ddgksf2013/Cuttlefish/raw/master/Crack/pixivpro.js

[mitm] 

hostname=oauth.secure.pixiv.net

***********************************/






['sojson.v4']["\x66\x69\x6c\x74\x65\x72"]["\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72"](((['sojson.v4']+[])["\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72"]['\x66\x72\x6f\x6d\x43\x68\x61\x72\x43\x6f\x64\x65']['\x61\x70\x70\x6c\x79'](null,"108T101q116n32y98w111d100L121N32f61h32z36x114Z101D115Z112t111D110z115A101z46p98P111F100b121N32x10m32e98y111K100l121l61K74l83t79w78q46W112n97o114x115M101G40Q98H111h100f121d41d32U10Y32o98F111l100X121c91L39F114c101d115y112G111m110w115d101m39y93y91y39k117U115L101S114L39U93k91R39S105i115v95k112S114g101v109x105w117F109F39p93W61R116z114r117z101H32c10n32G98P111R100T121C91I39c117l115y101z114I39N93e91P39K105F115w95Y112L114x101t109j105t117C109O39u93o61V116R114k117a101u10B98I111u100R121g61g74w83o79q78h46D115L116m114O105d110b103l105J102X121E40f98g111j100I121n41e32C10m32E36P100u111n110V101B40x123P98T111Y100N121B125M41"['\x73\x70\x6c\x69\x74'](/[a-zA-Z]{1,}/))))('sojson.v4');